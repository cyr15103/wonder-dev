
/**
 * @type {Object}
 */
var module = {};

/**
 * @type {Object}
 */
module.exports = {};
