/**
 * This callback type is completely empty, a no-operation.
 *
 * @callback Phaser.Types.Core.NOOP
 * @since 3.0.0
 */
